export default function Facebook() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 8 16"
      className="w-4 h-4"
      fill="currentColor"
    >
      <path d="M2.36471 16V8.70165H0V5.85734H2.36471V3.75974C2.36471 1.32549 3.79617 0 5.88693 0C6.88843 0 7.74916 0.0774437 8 0.112058V2.65599L6.54995 2.65667C5.41288 2.65667 5.19271 3.21786 5.19271 4.04137V5.85734H7.90452L7.55143 8.70165H5.19271V16H2.36471Z" />
    </svg>
  );
}
