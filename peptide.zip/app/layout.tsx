import type { Metadata } from "next";
import { Public_Sans, Poppins } from "next/font/google";
import "./globals.css";
import ReduxProvider from "@/redux/provider";
import { getSystemInfo } from "@/actions/quires/system_info.api";
import FaviconProvider from "./components/provider/FaviconProvider";
import PopupProvider from "./components/provider/PopupProvider";

const publicSans = Public_Sans({
  variable: "--font-public-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "Peptide",
  description: "For your digital solutions",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const systemInfo = await getSystemInfo();
  return (
    <html
      lang="en"
      className={`${publicSans.variable} ${poppins.className} h-full antialiased`}
    >
      <body>
        <FaviconProvider systemInfo={systemInfo} />
        <ReduxProvider>
          <PopupProvider>{children}</PopupProvider>
        </ReduxProvider>
      </body>
    </html>
  );
}
