export const tagTypes = ["auth"];
